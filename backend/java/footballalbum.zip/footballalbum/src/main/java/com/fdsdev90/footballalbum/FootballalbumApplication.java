package com.fdsdev90.footballalbum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FootballalbumApplication {

	public static void main(String[] args) {
		SpringApplication.run(FootballalbumApplication.class, args);
	}

}
