package com.fdsdev90.footballalbum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballalbumApplicationTests {

	@Test
	void contextLoads() {
	}

}
